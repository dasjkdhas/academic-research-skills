# Energies (MDPI) Submission Checklist

Manuscript: Energies_Manuscript_Yamaguchi_Campus_Cooling_Sensitivity_20260531.docx

## Hard requirements (verified)
- [x] Title (specific, descriptive, no shorthand)
- [x] Author list with affiliations and corresponding-author email
- [x] Abstract: 163 words (<=200 limit)
- [x] Keywords: 10 (range 3-10)
- [x] IMRaD structure: Introduction / Materials and Methods / Results /
      Discussion / Conclusions
- [x] Author Contributions (CRediT taxonomy phrasing)
- [x] Funding statement
- [x] Data Availability Statement
- [x] Acknowledgments
- [x] Conflicts of Interest declaration
- [x] References (18 entries, numeric citation style)
- [x] All figures cited in text in order
- [x] All figures at 600 dpi (MDPI minimum), RGB
- [x] All figures additionally provided as editable SVG (svg.fonttype=none)
- [x] All figures use sans-serif font (Liberation Sans / Arial)
- [x] Tables in editable format (Word tables, not images)

## Recommended additions before submitting
- [ ] Co-author name + affiliation + email
- [ ] Replace "[Supervisor]" / "[PI]" in Author Contributions
- [ ] Add ORCID iD for each author
- [ ] Add Funding number if any
- [ ] Add graphical abstract (optional but increases visibility)
- [ ] Cover letter (1 page)
- [ ] Choose Special Issue (e.g., "Energy Management in Buildings")

## Package contents
- figures_PNG_600dpi/    10 publication-ready PNG figures
- figures_SVG_editable/  10 editable SVG figures (text editable in Illustrator/Inkscape)
- supplementary_data/    4 CSV (power, AMeDAS, calendar, ERA5 core) + results JSON
- reproducibility_code/  4 Python scripts to re-derive everything
- Energies_Manuscript_*.docx  The manuscript

## Key numbers (for cover letter)
- Valid hourly samples: 7,358 of 8,760 fiscal-year hours
- Class-day cooling sensitivity: +37.0 kWh/h/C, R^2 = 0.91
- Weekend cooling sensitivity:   +23.3 kWh/h/C, R^2 = 0.90  (1.59x weaker)
- Balance-point temperature shift across calendar states: 4.0 C
- Maximum capacity-risk ratio rho: 0.897 (3 July 2025 14:00, 33.2 C, class day)
- All 14 Critical hours occurred on class days (100 %)

## Suggested target Special Issues
- "Energy Management in Buildings and Built Environment"
- "Demand-Side Management and Energy Efficiency in Buildings"
- "Climate-Sensitive Electricity Demand"
