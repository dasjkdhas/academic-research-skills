# Nature-style figure package

10 figures rebuilt to Nature submission specification.

## Style enforced
- White background
- Sans-serif Liberation Sans (Helvetica/Arial fallback)
- Tol's muted color-blind-safe palette (Class day = soft red #EE6677,
  Weekend = soft blue #4477AA, Vacation = soft green #228833)
- No chart frame; only left + bottom spines (0.5 pt)
- No grid
- Ticks outside, short (length 2.5 pt)
- Panel labels: italic bold lowercase a/b/c/d, top-left
- Legend: frameon=False, small (5.5-6 pt)
- Text never overlaps data: stats placed in legend or annotation box

## Sizing (Nature)
- Single column = 89 mm (3.5")
- Double column = 183 mm (7.2") — used for all panels here

## Export
- PNG: 600 dpi, RGB
- SVG: svg.fonttype=none — text remains editable in Illustrator / Inkscape

## Files
Figure_1_data_availability       data availability matrix
Figure_2_annual_timeseries       load + temperature year
Figure_3_daytype_profiles        boxplot + diurnal by day type
Figure_4_seasonal_signatures     hourly + daily by season
Figure_5_cooling_by_daytype      KEY RQ3 result
Figure_6_comfort_indices         T vs T_app vs WBGT vs HI
Figure_7_balance_point           building-physics interpretation
Figure_8_internal_heat_gains     occupant-load excess at matched WBGT
Figure_9_risk_concentration      (T × day type) capacity risk heatmap
Figure_10_rho_timeseries         capacity-risk time series
