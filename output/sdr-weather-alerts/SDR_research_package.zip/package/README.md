# SDR Research Package
山口大学キャンパス省エネ研究  — 翌日電力ピーク予測 + SDR運用支援

## パッケージ構成
- `docs/` — 方法論ピボット、結果、データ取得計画など解説文書
- `presentation/` — 省エネ研究会発表用PPT(12スライド) + 日本語講稿
- `figures_svg/` — 解析結果図表 (ベクター形式、編集可能)
- `figures_png/` — 同じ図のPNG版 (互換性用)
- `results/` — 数値結果JSON (再現性確認用)
- `code/` — 解析スクリプト Python (再実行可能)

## 主要な解析内容
1. 探索的データ分析 (日内パターン、月別)
2. **気象 × 電力 相関分析** (Pearson/Spearman/標準化β)
3. **主成分分析 (PCA)** — 気象10変数を3主成分(76%変動)に圧縮
4. **3アーキテクチャ比較**: 観測のみ / 予報のみ / ハイブリッド
5. ハイブリッド翌日予測モデル (LightGBM)
6. SHAP による特徴量重要度

## 主要結果
- ハイブリッド手法: holdout MAE = 54.0 kW, R² = 0.905, MAPE = 7.3%
- 予報のみベースラインから MAE 10% 改善
- 観測上限から MAE わずか 6% 差
- 気象変数だけで b00 分散の 53% を説明
- PC1 (熱関連) — b00 相関 r=+0.47
- PC2 (湿度×日射) — b00 相関 r=−0.50

## 図表一覧 (figures_svg/, figures_png/)

### 探索的分析 + データ
- `pres_01_overview_daily_profile` — 月別 時刻別 平均消費電力
- `pres_02_temp_load_scatter` — 外気温 × 電力 散布図
- `pres_07_train_test_split` — 学習/テスト分割可視化

### 気象 × 電力 相関分析
- `corr_01_pearson_heatmap` — 相関係数ヒートマップ(時間別)
- `corr_02_daily_heatmap` — 相関係数ヒートマップ(日単位)
- `corr_03_scatter_grid` — 6気象変数 × 電力 散布図
- `corr_04_hourly_stratified` — 時刻別 層別化相関
- `corr_07_standardized_beta` — 標準化回帰係数 β
- `corr_08_framework` — 解析フレームワーク (電力✓ + ガス予約)

### 主成分分析 (PCA)
- `corr_05_pca_variance` — 主成分の寄与率
- `corr_06_pca_loadings` — 主成分の構成 + b00との相関

### 予測モデル結果
- `pres_03_arch_compare` — 3アーキテクチャ MAE/R²比較
- `pres_04_holdout_timeseries` — テスト期間 実測 vs 予測
- `pres_05_pred_vs_actual` — 予測 vs 実測 散布図
- `pres_06_shap_top10` — SHAP特徴量重要度 Top10

## 再現方法
```bash
cd code/
python 13_clean_figures_for_presentation.py    # 探索 + 結果図
python 14_build_presentation_ppt.py             # PPT生成
python 15_correlation_and_pca_analysis.py       # 相関 + PCA
```

## ライセンス & 引用
研究室内利用および学会発表用。外部公開時は要相談。

## バージョン情報
- パッケージ作成日: 2026-05-17
- データ範囲: 2025-07-20 〜 2025-10-26 (有効2,145時間)
- 解析ブランチ: claude/sdr-weather-alerts-research-CwlkS
